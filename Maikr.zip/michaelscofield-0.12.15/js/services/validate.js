(function() {
	var validate;
	validate = function() {
		this.ip = function(ipaddress) {
			/*
			var part, parts;
			if (!str) {
				return false
			}
			parts = str.split('.');
			return parts.length === 4 && _.every((function() {
				var _i, _len, _results;
				_results = [];
				for (_i = 0, _len = parts.length; _i < _len; _i++) {
					part = parts[_i];
					_results.push(isNaN(part))
				}
				return _results
			})())
*/
			  if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ipaddress)) {  
			    return (true)  
			  }  
			  //alert("You have entered an invalid IP address!")  
			  return (false)  
		};

		this.cidr = function(cidr) {

			  if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\/([0-9]|[1-2][0-9]|3[0-2]))$/.test(cidr)) {  
			    return (true)  
			  }  
			  //alert("You have entered an invalid IP address!")  
			  return (false)  
		};
	

		this.email = function(str) {
			return str && str.length >= 6 && /^[\w\-\.]+@[\w\-]+(\.\w+)+$/.test(str)
		};
		this.phone = function(str) {
			return str && str.length === 11 && /^1(\d)+$/.test(str)
		};

		this.domain = function(str) {
			/*
			var d, _ref;
			if (!str) {
				return false
			}
			d = str.trim();
			return d && (0 < (_ref = d.indexOf('.')) && _ref < (d.length - 1))
			*/
  		    var regex = /([a-z0-9])?([a-z0-9]+\.)*[a-z0-9]+\.[a-z.]+/ig;

            if(!regex .test(str)) {
          	    return false;
            } else {
			    return true;
            }


		};

		this.domainOrDomainPart = function(str){
  		    var regex = /([a-z])([a-z0-9]+\.)*[a-z0-9]+/ig;

            if(!regex .test(str)) {
          	    return false;
            } else {
			    return true;
            }
		};
		
		this.url = function(str){
  		    var regex = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;

            if(!regex .test(str)) {
          	    return false;
            } else {
			    return true;
            }

		};
		this.cidr_contains = function(cidr_ip, ip) {
			if(!this.cidr(cidr_ip)){
				return cidr_ip === ip;
			}
			var cidr = new CidrAddress(cidr_ip);
			return cidr.has(ip);
		};
		this.cidr_overlap = function(cidr_ip_1, cidr_ip_2) {
			var cidr_1 = new CidrAddress(cidr_ip_1);
			var cidr_2 = new CidrAddress(cidr_ip_2);
			return cidr_1.overlap(cidr_2);
		};
		return this
	};
	define(['../app', 'underscore', 'cidr'], function(app, _) {
		return app.service('validate', validate)
	})
}).call(this);