(function() {
	var invitationManager, libs;
	invitationManager = function($window, $rootScope, $log, $http, $timeout, userManager, SERVER) {
		var _inviter;


		this.getInvitationList  = function(invitationList, me){
			if(!invitationList || invitationList.length == 0) return [];
			var i;
			var ret = [];
			//console.log(me);
			for(i = 0 ; i < invitationList.length ; i++){
				
				var invitation = invitationList[i];
				/*
				invitation.can_fetch_reward = false;

				if(invitation.can_fetch_reward_receiver && invitation.receiver_id === me){
					invitation.can_fetch_reward = true;
				}

				if(invitation.can_fetch_reward_sender   && invitation.sender_id === me){
					invitation.can_fetch_reward = true;
				}
				*/
				ret.push(invitation);
			}
			return ret;
		};

		/*
		this.getCanFetchRewardCount = function(invitationList, me){
			if(!invitationList || invitationList.length == 0) return 0;
			var list = _.filter(invitationList,
				function(invitation) {
					return invitation.can_fetch_reward;
				}
			);
			return list.length;
		};
		*/
		this.getCanFetchRewardCount = function(invitationList, me){
			if(!invitationList || invitationList.length == 0) return 0;
			var list = _.filter(invitationList,
				function(invitation) {
					return invitation.can_fetch_reward && !invitation.expired;
				}
			);
			return list.length;
		};

		this.fetchInvitationReward = function(invitation){
			userManager.fetchInvitationReward(invitation.id);
		};
		this.resendBindEmailVerification = function(email){
			userManager.resendBindEmailVerification(email);
		};
		/*
		this.queryInvitationList = function() {
			return $http.get(SERVER.scheme + SERVER.host + SERVER.contextPath + "/user/invitation_list?sid=" + $rootScope.user.profile.sid).success(function(resp) {
				if (resp.invitation_list) {
					return $rootScope.invitationList = resp.invitation_list
				}
			})
		};

		
		_inviter = '';
		this.queryInviter = function(callback) {
			var inviterQueryUrl;
			if (!_inviter) {
				inviterQueryUrl = SERVER.scheme + SERVER.host + SERVER.contextPath + "/user/get_inviter?sid=" + $rootScope.user.profile.sid;
				return $http.get(inviterQueryUrl).success(function(resp) {
					_inviter = resp.inviter;
					return callback(_inviter)
				})
			} else {
				return $timeout(function() {
					return callback(_inviter)
				})
			}
		};
		*/
		return this
	};
	libs = ['../app', './userManager']
	define(libs, function(app) {
		return app.service('invitationManager', invitationManager)
	})
}).call(this);